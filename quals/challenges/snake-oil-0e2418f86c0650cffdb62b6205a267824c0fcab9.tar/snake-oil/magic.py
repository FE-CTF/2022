import os,sys
_ = 'aIaabVaacaXadaaaeaaafaaagaaahaaaiaaajaaakaaalaaamaLanaaaoaaapaaaqaaaraaa'\
    'saaataaauaaavaaawaaaxaaayaaaCaabbaabcaabdaabeaabfaabgaabhaabiaabjaabkaab'\
    'laabmaabnaaboaabpaabqaabraabsaabtaabuaabvaabwaabxaabyaabzaacbaaccaacdaac'\
    'eaacfaacgaachaaciaacjaackaaclaacmaacnaacoaacpaacqaacraacsaactaacuaacvaac'\
    'waacxaacyaaczaadbaadcaaddaadeaadfaadgaadhaadiaadjaadkaadlaadmaadnaadoaad'\
    'paadqaadraadsaadtaaduaadvaadwaadxaadyaadzaaebaaecaaedaaeeaaefaaegaaehaae'\
    'iaaejaaekaaelaaemaaenaaeoaaepaaeqaaeraaesaaetaaeuaaevaaewaaexaaeyaaeDaaf'\
    'baafcaafdaafeaaffaafgaafhaafiaafjaafkaaflaafmaafnaafoaafpaafqaafraafsaaf'\
    'taafuaafvaafwaafxaafyaafzaagbaagcaagdaageaagfaaggaaghaagiaagjaagkaaglaag'\
    'maagnaagoaagpaagqaagraagsaagtaaguaagvaagwaagxaagyaagzaahbaahcaahdaaheaah'\
    'faahgaahhaahiaahjaahkaahlaahmaahnaahoaahpaahqaahraahsaahtaahuaahvaahwaah'\
    'xaahyaahzaaibaaicaaidaaieaaifaaigaaihaaiiaaijaaikaailaaimaainaaioaaipaai'\
    'qaairaaisaaitaaiuaaivaaiwaaixaaiyaaizaajbaajcaajdaajeaajfaajgaajhaajiaaj'\
    'jaajkaajlaajmaajnaajoaajpaajqaajraajsaajtaajuaajvaajwaajxaajyaajMaakbaak'
def __(a):
    b=sorted(_ for _ in enumerate(_)if _[True].isupper())[::~False]
    c=''
    d=False
    f=a
    while a:
        if a>=b[d][False]:
            c+=b[d][True]
            a+=~b[d][False]+True
            continue
        if a>=b[d][False]*(9-b[d][False]//b[-~d][False]%2)//0o12:
            a-=b[d][False]
            e=min(_[False]for _ in b if a+_[False]>=False)
            c+=dict(b)[e]
            c+=b[d][True]
            a+=e
        d=-~d
    setattr(sys.modules[__name__],c,f)
    return c
__(True)
[__(_)for(_)in(range(I+I,I+I+I+I+I+I+I+I+I+I+I+I))]
{__((XI**_-I)//II):__(XI**_-I)for(_)in(range(I,V))}
class A(object):
    def __pos__(_):
        return sys.stdin.buffer.read(I)[False]
    def __add__(_,__):
        sys.stdout.buffer.write(bytes([__]))
        sys.stdout.buffer.flush()
    def __mul__(_,__):
        for __ in __.encode('latin1'):
            _+__
class B(object):
    _=lambda x:lambda y,z:y(x,z)
    __or__=_(VIII)
    def __init__(_):
        _.a,_.b,_.c=(False,)*III
    __add__=_(False)
    def __call__(_,__,___):
        x=B()
        x.b=_.b-~___.b
        x.c=x.a=___.a*XI**(_.b+True)+__*XI**_.b+_.a
        ___.c=_.c=_.c^_.c
        return x
    __mul__=_(II)
    __xor__=_(V)
    __sub__=_(I)
    __mod__=_(IV)
    __truediv__=_(IX)
    def __lt__(__,___):
        global _
        _=(_ or __)(VII,___)
        return _
    __and__=_(VI)
    def __gt__(__,___):
        global _
        _=(_ or __)(X,___)
        return _
    __matmul__=_(III)
    def __getitem__(_,__):
        __%=XI**V
        __*=V
        return _.a//XI**__%XI**V
    def __setitem__(_,__,___):
        ____=_[__]
        __%=XI**V
        __*=V
        _.a+=(___-____)*XI**__
    def __del__(__):
        if not __.c:return
        _ = A()
        a = [False]*XI
        while X:
            a=[(_%XI**V)for(_)in(a)]
            b=__[a[False]];a[False]-=~False
            b,c=divmod(b,XI)
            b,d=divmod(b,XI)
            b,e=divmod(b,XI)
            b,f=divmod(b,XI)
            b,g=divmod(b,XI)
            h=f+g*XI
            i=e+h*XI
            j=d+i*XI
            if False:
                print(open('flag').read())
            elif c==V:
                a[False]+=j-MMMMMMMCCCXX
            elif c==II:
                a[d]=__[a[e]+f-V]
                a[e]+=g-V
            elif c==III:
                __[a[e]+f-V]=a[d]
                a[e]+=g-V
            elif c==IV:
                a[d]=i
            elif not c:
                if not d|e|f|g:
                    break
                elif I<=d<=VIII:
                    d-=True
                    if[
                            lambda a,_:a==False,
                            lambda a,_:a!=False,
                            lambda a,b:a==b,
                            lambda a,b:a!=b,
                            lambda a,b:a>b,
                            lambda a,b:a>=b,
                            lambda a,b:a<b,
                            lambda a,b:a<=b,
                    ][d](a[e],a[f]):
                        a[False]+=I
            elif c==VII:
                a[d]+=i-DCLXV
            elif c==VIII:
                if not d:
                    a[e]+=MCCCXXXI*h
                elif d==I:
                    __[a[e]]=h-LX
            elif c==VI:
                if d<=VII:
                    a[e]=[
                        lambda a,b:a+b,
                        lambda a,b:a-b,
                        lambda a,b:a*b,
                        lambda a,b:a//b,
                        lambda a,b:a%b,
                        lambda a,b:min(a,b),
                        lambda a,b:max(a,b),
                        lambda a,b:~(a+b),
                    ][d](a[f],a[g])
            elif c==IX:
                a[IX]=a[False]
                a[False]+=j-MMMMMMMCCCXX
            elif c==X:
                a[d]=eval((__.a//XI**(a[e]*V)%XI**(a[f]*V)).to_bytes(a[f]*III,'little').decode('latin1').strip('\0'))or(0)
            elif not ~-c:
                a[d]=a[e]
                a[f]=a[g]
_=setattr(sys.modules['__main__'],'_',B())
