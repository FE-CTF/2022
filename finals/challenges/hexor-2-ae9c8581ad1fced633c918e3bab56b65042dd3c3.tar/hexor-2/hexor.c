#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>

#define u8 uint8_t
#define u16 uint16_t
#define u32 uint32_t
#define u64 uint64_t

#define array_length(x) ((size_t) sizeof(x) / sizeof(x[0]))

struct rc4_ctx {
    u8 S[256];
};

void swap(u8 *a, u8 *b) {
    int tmp = *a;
    *a = *b;
    *b = tmp;
}

int rc4_init(struct rc4_ctx *ctx, const u8 *key) {

    int len = array_length(key);
    int j = 0;

    for(u32 i = 0; i < array_length(ctx->S); i++)
        ctx->S[i] = i;

    for(u32 i = 0; i < array_length(ctx->S); i++) {
        j += ctx->S[i] + ((char *)key)[i % len];
        j %= sizeof(ctx->S);

        swap(&ctx->S[i], &ctx->S[j]);
    }

    return 0;
}

int rc4_crypt(struct rc4_ctx *ctx, u8 *buffer, u32 len) {

    int i = 0, j = 0;

    for (size_t n = 0; n < len; n++) {
        i = (i + 1) % array_length(ctx->S);
        j = (j + ctx->S[i]) % array_length(ctx->S);

        swap(&ctx->S[i], &ctx->S[j]);
        int rnd = ctx->S[(ctx->S[i] + ctx->S[j]) % array_length(ctx->S)];

        buffer[n] = rnd ^ buffer[n];
    }
    return 0;
}

int main(int argc, char *argv[])
{
    if (argc != 2) {
        fprintf(stderr, "usage: %s <key>\n", argv[0]);
        fprintf(stderr, "\nto encrypt:\n  $ %s verysafekey < plain.txt > encrypt.bin\n", argv[0]);
        fprintf(stderr, "\nto decrypt:\n  $ %s verysafekey < encrypt.bin > plain.txt\n", argv[0]);
        exit(1);
    }

    const u8 *key = (u8 *) argv[1];

    /* Initialize encryption context */
    struct rc4_ctx ctx;
    rc4_init(&ctx, key);

    u8 buf[128];

    /* Process everything from stdin in sizeof(buf)-sized chunks */
    for (;;) {
        /* try to fill the buffer from stdin */
        int nread = read(STDIN_FILENO, buf, sizeof(buf));
        if (nread < 1)
            break;

        /* encrypt the contents in "buf" */
        rc4_crypt(&ctx, buf, nread);

        /* if we can't write all bytes, an error must have occured */
        if (write(STDOUT_FILENO, buf, nread) != nread)
            break;
    }

    return 0;

}
