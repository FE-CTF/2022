#!/usr/bin/env python3
import binascii
import json
import math
import os
import random
import signal
import sys
from seccomp import SyscallFilter, Arg, ALLOW, EQ, KILL
from types import CodeType

N = 0x100
R = 1000
T = 120

def alice(xs, k):
    ...

def bob(xs):
    ...

def inject(f, brains):
    f.__code__ = CodeType(
        f.__code__.co_argcount,
        f.__code__.co_posonlyargcount,
        f.__code__.co_kwonlyargcount,
        f.__code__.co_nlocals,
        f.__code__.co_stacksize,
        f.__code__.co_flags,
        brains,
        f.__code__.co_consts,
        f.__code__.co_names,
        f.__code__.co_varnames,
        f.__code__.co_filename,
        f.__code__.co_name,
        f.__code__.co_firstlineno,
        f.__code__.co_lnotab,
        f.__code__.co_freevars,
        f.__code__.co_cellvars,
    )

def recv(io):
    fd, _ = io
    r = b''
    while True:
        c = os.read(fd, 1)
        if c in (b'', b'\0'):
            break
        r += c
    if not r:
        return
    return json.loads(r)

def send(io, data):
    _, fd = io
    os.write(fd, bytes(json.dumps(data), 'utf8') + b'\0')

def close(io):
    i, o = io
    os.close(i)
    os.close(o)

def jail(f):
    pi, co = os.pipe()
    ci, po = os.pipe()
    pio = pi, po
    cio = ci, co
    if os.fork():
        close(cio)
        return pio
    else:
        for fd in range(3, 1024):
            if fd not in cio:
                try:
                    os.close(fd)
                except:
                    pass
        random.seed(0)
        flt = SyscallFilter(defaction=KILL)
        flt.add_rule(ALLOW, "write", Arg(0, EQ, co))
        flt.add_rule(ALLOW, "read",  Arg(0, EQ, ci))
        flt.add_rule(ALLOW, "brk")
        flt.load()
        while True:
            args = recv(cio)
            if not args:
                break
            send(cio, f(*args))
        sys.exit(0)

def call(io, *args):
    send(io, args)
    return recv(io)

def main():
    signal.alarm(T)
    inject(alice, binascii.unhexlify(input("Alice's brain: ")))
    inject(bob, binascii.unhexlify(input("Bob's brain: ")))
    a = jail(alice)
    b = jail(bob)

    S = math.isqrt(N)
    for r in range(R):
        print(f'[Round #{r}]')
        xs = [random.choice((True, False)) for _ in range(N)]
        k = random.randrange(0, N)
        print(f'k = {k}, xs =')
        for y in range(S):
            for x in range(S):
                i = y * S + x
                if i == k:
                    sys.stdout.write('\x1b[31;1m')
                sys.stdout.write(' ' + 'XO'[xs[y * S + x]])
                if i == k:
                    sys.stdout.write('\x1b[m')
            print()
        i = call(a, xs, k)
        print(f'Alice = {i}')
        xs[i] ^= True
        j = call(b, xs)
        print(f'Bob = {j}')
        sys.stdout.flush()
        assert k == j

    with open('flag') as f:
        print(f.read())

if __name__ == '__main__':
    main()
