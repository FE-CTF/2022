#!/usr/bin/env python2.7
import sys
import hashlib

def die(s):
    print >>sys.stderr, s
    sys.exit(1)

def init(key):
    s = hashlib.sha256(key).digest()
    n = 0
    code = range(0x100)
    for i in xrange(10000):
        if i % 16 == 0:
            s = hashlib.sha256(s).digest()
        n += ord(s[i & 0xf])
        code[i & 0xff], code[n & 0xff] = code[n & 0xff], code[i & 0xff]
    return code

def encipher(code):
    c = '\0'
    while True:
        p = sys.stdin.read(1)
        if not p:
            break
        # Almost like CBC, so must be good
        x = (ord(c) + ord(p)) & 0xff
        c = chr(code[x])
        sys.stdout.write(c)

def decipher(code):
    c1 = '\0'
    while True:
        c2 = sys.stdin.read(1)
        if not c2:
            break
        x = code.index(ord(c2))
        p = chr((x - ord(c1)) & 0xff)
        sys.stdout.write(p)
        c1 = c2

if __name__ == '__main__':
    if len(sys.argv) != 3:
        die('usage: %s <key> (enc|dec) < infile > outfile' % sys.argv[0])
    key, cmd = sys.argv[1:]
    code = init(key)
    if cmd == 'enc':
        encipher(code)
    elif cmd == 'dec':
        decipher(code)
    else:
        die('invalid command')
