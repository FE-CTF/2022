#!/usr/bin/env pypy3
import sys
import hashlib
import struct

P = 89513

def stream(key):
    x = 0
    y = 0
    for z in struct.unpack('<HHHHHHHHHH', hashlib.sha1(key).digest()):
        x ^= z
        x, y = y, x
    while True:
        yield x
        x, y = y, (x + y) % P

if len(sys.argv) != 2:
    print(f'usage: {sys.argv[0]} PASSWORD < INFILE > OUTFILE', file=sys.stderr)
    exit(1)

S = stream(sys.argv[1].encode())

# Protect against brute force attacks
for _ in range(0x10000000):
    next(S)

while True:
    k = next(S)
    for _ in range(2):
        try:
            b, = sys.stdin.buffer.read(1)
        except ValueError:
            exit(0)
        sys.stdout.buffer.write(bytes([b ^ k & 0xff]))
        k >>= 8
